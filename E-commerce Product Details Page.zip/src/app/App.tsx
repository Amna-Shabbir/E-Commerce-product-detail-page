import { useState } from 'react';
import { ImageGallery } from './components/ImageGallery';
import { ProductVariants } from './components/ProductVariants';
import { AddToCartButton } from './components/AddToCartButton';
import { Badge } from './components/ui/badge';
import { Separator } from './components/ui/separator';
import { Heart, Truck, RefreshCw, Shield, Star } from 'lucide-react';
import { motion } from 'motion/react';

const productImages = [
  'https://images.unsplash.com/photo-1763189851330-23f36450bbde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB3YXRjaCUyMHByb2R1Y3QlMjB3aGl0ZSUyMGJhY2tncm91bmR8ZW58MXx8fHwxNzcyNjM0NTEzfDA&ixlib=rb-4.1.0&q=80&w=1080',
  'https://images.unsplash.com/photo-1597806193787-6feafde0b613?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRjaCUyMGNsb3NldXAlMjBkZXRhaWxzfGVufDF8fHx8MTc3MjY5Njc5OXww&ixlib=rb-4.1.0&q=80&w=1080',
  'https://images.unsplash.com/photo-1762114460411-ab1e0be4a7d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRjaCUyMHNpZGUlMjB2aWV3JTIwcHJvZHVjdHxlbnwxfHx8fDE3NzI3MjkyMTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
  'https://images.unsplash.com/photo-1734776579769-4fbfcdd12b6a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRjaCUyMGJhY2slMjBjYXNlJTIwcHJvZHVjdHxlbnwxfHx8fDE3NzI3MjkyMTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
];

export default function App() {
  const [selectedSize, setSelectedSize] = useState('40mm');
  const [selectedColor, setSelectedColor] = useState('Black');
  const [isFavorited, setIsFavorited] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column - Image Gallery */}
          <div className="lg:sticky lg:top-8 lg:self-start">
            <ImageGallery images={productImages} />
          </div>

          {/* Right Column - Product Information */}
          <div className="space-y-6">
            {/* Product Header */}
            <div>
              <Badge className="mb-3">New Arrival</Badge>
              <h1 className="text-4xl mb-2">Premium Swiss Chronograph</h1>
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-4 h-4 fill-yellow-400 text-yellow-400"
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-600">(248 reviews)</span>
              </div>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3">
              <span className="text-3xl">$1,299.00</span>
              <span className="text-xl text-gray-400 line-through">$1,599.00</span>
              <Badge variant="destructive" className="ml-2">-19%</Badge>
            </div>

            <Separator />

            {/* Description */}
            <div>
              <p className="text-gray-600 leading-relaxed">
                Crafted with precision and elegance, this Swiss chronograph combines timeless design with modern functionality. Features include a sapphire crystal display, automatic movement, and water resistance up to 100m. The perfect accessory for any occasion.
              </p>
            </div>

            {/* Product Variants */}
            <ProductVariants
              selectedSize={selectedSize}
              onSizeChange={setSelectedSize}
              selectedColor={selectedColor}
              onColorChange={setSelectedColor}
            />

            <Separator />

            {/* Action Buttons */}
            <div className="flex gap-3">
              <div className="flex-1">
                <AddToCartButton />
              </div>
              <motion.button
                onClick={() => setIsFavorited(!isFavorited)}
                className={`p-4 rounded-lg border-2 transition-colors ${
                  isFavorited
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                whileTap={{ scale: 0.95 }}
              >
                <Heart
                  className={`w-6 h-6 transition-colors ${
                    isFavorited ? 'fill-red-500 text-red-500' : 'text-gray-600'
                  }`}
                />
              </motion.button>
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <Truck className="w-5 h-5 text-gray-700 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-medium text-sm mb-1">Free Shipping</h3>
                  <p className="text-xs text-gray-600">On orders over $500</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <RefreshCw className="w-5 h-5 text-gray-700 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-medium text-sm mb-1">30-Day Returns</h3>
                  <p className="text-xs text-gray-600">Money back guarantee</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <Shield className="w-5 h-5 text-gray-700 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-medium text-sm mb-1">2-Year Warranty</h3>
                  <p className="text-xs text-gray-600">Full manufacturer warranty</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                <Star className="w-5 h-5 text-gray-700 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-medium text-sm mb-1">Premium Quality</h3>
                  <p className="text-xs text-gray-600">Swiss craftsmanship</p>
                </div>
              </div>
            </div>

            {/* Product Details */}
            <Separator />

            <div className="space-y-4">
              <h2 className="text-xl font-medium">Product Details</h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Movement</span>
                  <span className="font-medium">Automatic</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Case Material</span>
                  <span className="font-medium">Stainless Steel</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Water Resistance</span>
                  <span className="font-medium">100m (10 ATM)</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Crystal</span>
                  <span className="font-medium">Sapphire</span>
                </div>
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span className="text-gray-600">Warranty</span>
                  <span className="font-medium">2 Years International</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
