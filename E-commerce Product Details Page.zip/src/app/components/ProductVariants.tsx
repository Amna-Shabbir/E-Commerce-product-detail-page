import { motion } from 'motion/react';

interface ProductVariantsProps {
  selectedSize: string;
  onSizeChange: (size: string) => void;
  selectedColor: string;
  onColorChange: (color: string) => void;
}

const sizes = ['38mm', '40mm', '42mm', '44mm'];
const colors = [
  { name: 'Black', value: '#000000' },
  { name: 'Silver', value: '#C0C0C0' },
  { name: 'Gold', value: '#D4AF37' },
  { name: 'Rose Gold', value: '#B76E79' },
];

export function ProductVariants({
  selectedSize,
  onSizeChange,
  selectedColor,
  onColorChange,
}: ProductVariantsProps) {
  return (
    <div className="space-y-6">
      {/* Size Selection */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="text-sm font-medium text-gray-900">Size</label>
          <span className="text-sm text-gray-500">{selectedSize}</span>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {sizes.map((size) => (
            <motion.button
              key={size}
              onClick={() => onSizeChange(size)}
              className={`relative py-3 px-4 rounded-lg border-2 transition-colors ${
                selectedSize === size
                  ? 'border-black bg-black text-white'
                  : 'border-gray-200 bg-white text-gray-900 hover:border-gray-300'
              }`}
              whileTap={{ scale: 0.95 }}
            >
              {size}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Color Selection */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <label className="text-sm font-medium text-gray-900">Color</label>
          <span className="text-sm text-gray-500">{selectedColor}</span>
        </div>
        <div className="flex gap-3">
          {colors.map((color) => (
            <motion.button
              key={color.name}
              onClick={() => onColorChange(color.name)}
              className={`relative w-12 h-12 rounded-full border-2 transition-all ${
                selectedColor === color.name
                  ? 'border-black scale-110'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              whileTap={{ scale: 0.9 }}
              title={color.name}
            >
              <div
                className="w-full h-full rounded-full"
                style={{ backgroundColor: color.value }}
              />
              {selectedColor === color.name && (
                <motion.div
                  className="absolute inset-0 rounded-full border-2 border-black"
                  layoutId="colorIndicator"
                  transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                />
              )}
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
