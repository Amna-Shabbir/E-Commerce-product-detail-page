import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, Check } from 'lucide-react';

export function AddToCartButton() {
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = () => {
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <motion.button
      onClick={handleAddToCart}
      disabled={isAdded}
      className={`relative w-full py-4 px-8 rounded-lg font-medium transition-colors ${
        isAdded
          ? 'bg-green-500 text-white'
          : 'bg-black text-white hover:bg-gray-800'
      }`}
      whileTap={{ scale: isAdded ? 1 : 0.98 }}
    >
      <AnimatePresence mode="wait">
        {isAdded ? (
          <motion.div
            key="added"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex items-center justify-center gap-2"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 400, damping: 15 }}
            >
              <Check className="w-5 h-5" />
            </motion.div>
            Added to Cart
          </motion.div>
        ) : (
          <motion.div
            key="add"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="flex items-center justify-center gap-2"
          >
            <ShoppingCart className="w-5 h-5" />
            Add to Cart
          </motion.div>
        )}
      </AnimatePresence>

      {/* Success Animation Particles */}
      <AnimatePresence>
        {isAdded && (
          <>
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-white rounded-full"
                initial={{
                  x: '50%',
                  y: '50%',
                  scale: 0,
                }}
                animate={{
                  x: `${50 + Math.cos((i * Math.PI * 2) / 6) * 100}%`,
                  y: `${50 + Math.sin((i * Math.PI * 2) / 6) * 100}%`,
                  scale: [0, 1, 0],
                }}
                exit={{ scale: 0 }}
                transition={{
                  duration: 0.6,
                  ease: 'easeOut',
                }}
              />
            ))}
          </>
        )}
      </AnimatePresence>
    </motion.button>
  );
}
